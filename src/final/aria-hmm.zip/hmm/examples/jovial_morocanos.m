% Authors: Alexandru Sorici, Tudor Berariu / August 2012

%% incarca parametrii MMA
% jovialul
A1 = [0.8 0.1 0.1 ; 0.25 0.25 0.5; 0.8 0.2 0];
B1 = [0.7 0.3 0 ; 0 0.7 0.3 ; 0.6 0 0.4];
Pi1 = [0.7 0.2 0.1];
% morocanosul
A2 = [0.5 0.3 0.2 ; 0.1 0.6 0.3; 0.4 0.5 0.1];
B2 = [0.4 0.5 0.1 ; 0 0.2 0.8 ; 0.6 0 0.4];
Pi2 = [0.3 0.5 0.2];

%% secventa de observatii
O = [1 1 3]; %zambet, zambet, incruntare



